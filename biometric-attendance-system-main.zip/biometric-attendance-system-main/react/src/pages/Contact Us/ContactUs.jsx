import React from 'react'
import Navbar from '../../Components/Navbar/Navbar'

const ContactUs = () => {
  return (
    <div>
        <Navbar/>
      Contact Us
    </div>
  )
}

export default ContactUs
