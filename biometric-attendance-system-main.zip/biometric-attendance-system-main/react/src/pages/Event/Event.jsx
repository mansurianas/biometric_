import React from 'react'
import Navbar from '../../Components/Navbar/Navbar'

const Event = () => {
  return (
    <div>
        <Navbar/>
      Event and Notices
    </div>
  )
}

export default Event
